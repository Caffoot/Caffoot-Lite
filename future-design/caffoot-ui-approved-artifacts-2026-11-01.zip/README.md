# Caffoot Lite — preserved visual source files

Collected 1 November 2026. This is a locally packaged copy of the actual files available in this project conversation, NOT a claim that previously lost screenshots were recovered.

## Approved visual references

- `my-account/approved-my-account-personal-details-2026-11-01.png` — owner-approved revised My Account image with round avatar, personal details, slightly angled official Caffoot sidebar mark and global typography reference. The generated image includes provisional mockup footer text; the owner approved the **visual design**.
- `settings-and-data/concept-04.1/*` — actual self-contained interactive HTML, written design record and three exact preview screenshots. Owner approved Concept 04 with the corrected compact SMTP switch in 04.1. The prototype is illustrative, not live application code.

## Historical / superseded references

- `my-account/draft-01/*` — actual earlier self-contained HTML, design record and four preview screenshots for previous My Account Draft 01. This predates Personal Details and is NOT the approved final Overview, but is useful for interaction/reference history.

## Known limits

The exact original art for most other screens is not in these files. Their decisions are recorded in GitHub issue #227. All future design changes should archive both actual assets and written approvals together, in a repository folder, not rely on chats.

## Safety

- No production changes.
- No live user information or credentials; demo screens use fictional examples.
- No application implementation authorised.
